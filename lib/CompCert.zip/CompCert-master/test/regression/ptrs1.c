const char * f(char * p, const char * q) { return p == q ? p : q; }
