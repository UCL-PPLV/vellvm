extern int f(int x);

double g(int x) { return 3.14 * f(x); }

