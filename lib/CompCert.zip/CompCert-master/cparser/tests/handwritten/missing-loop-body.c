int main (void)
{
  int x = 10;
  while (x--) /* missing loop body */
}
